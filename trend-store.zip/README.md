# Trend Store — ZIP Build Pack

This is a scaffolded monorepo for a standalone shop inspired by Woo + Shopify.
Includes:
- Postgres schema (Prisma)
- Seed script
- Minimal Next.js app scaffold
- Worker scaffold

Next steps: wire the full APIs + admin UI (CSV mapper, headless checkout, etc.) into apps/web.
