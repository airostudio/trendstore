export default function Page(){return(<main style={{padding:24}}><h1>Trend Store</h1><p>Build pack scaffold.</p></main>)}
