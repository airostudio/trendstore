console.log('Trend Store worker scaffold');
